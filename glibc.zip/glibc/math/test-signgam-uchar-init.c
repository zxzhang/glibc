#define TYPE unsigned char
#define DO_INIT 1
#include "test-signgam-main.c"
