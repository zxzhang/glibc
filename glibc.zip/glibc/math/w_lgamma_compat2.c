#define USE_AS_COMPAT 0
#include <w_lgamma_main.c>
