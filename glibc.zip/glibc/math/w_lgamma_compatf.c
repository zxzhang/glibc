#define USE_AS_COMPAT 1
#include <w_lgammaf_main.c>
