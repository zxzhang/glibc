#define USE_AS_COMPAT 0
#include <w_lgammal_main.c>
