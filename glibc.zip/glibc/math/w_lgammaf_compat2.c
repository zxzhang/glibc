#define USE_AS_COMPAT 0
#include <w_lgammaf_main.c>
