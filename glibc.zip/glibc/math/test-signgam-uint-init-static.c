#include "test-signgam-uint-init.c"
