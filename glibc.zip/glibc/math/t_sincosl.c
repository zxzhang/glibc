/* Empty.  Not needed unless ldbl __kernel_* functions use it. */
