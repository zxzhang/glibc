#define CHECK_CAN_TEST ((void) 0)
#include <test-fenv-clear-main.c>
