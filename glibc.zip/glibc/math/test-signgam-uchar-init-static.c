#include "test-signgam-uchar-init.c"
