/* This function is the same as nextafterl so we use an alias there.  */
