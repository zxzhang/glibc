#include "test-signgam-ullong-init.c"
