#define USE_AS_COMPAT 1
#include <w_lgamma_main.c>
