#define USE_AS_COMPAT 1
#include <w_lgammal_main.c>
