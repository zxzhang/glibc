#define TYPE unsigned char
#define DO_INIT 0
#include "test-signgam-main.c"
