#include <math-type-macros-float.h>
#include <w_remainder_template.c>
#if __USE_WRAPPER_TEMPLATE
weak_alias (__remainderf, dremf)
#endif
