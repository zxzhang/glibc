#include "test-signgam-uchar.c"
