#define TYPE unsigned long long int
#define DO_INIT 0
#include "test-signgam-main.c"
